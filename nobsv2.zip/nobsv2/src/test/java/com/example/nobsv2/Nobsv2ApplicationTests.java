package com.example.nobsv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Nobsv2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
